package jaxb_demo;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.dmg.pmml.ObjectFactory;
import org.dmg.pmml.PMML;

public class UnmarshalDemo {

	static
	public void main(String... args) throws Exception {
		JAXBContext context = JAXBContext.newInstance(ObjectFactory.class);

		Unmarshaller unmarshaller = context.createUnmarshaller();

		PMML pmml = (PMML)unmarshaller.unmarshal(new StreamSource(System.in));

		System.out.println(pmml + " (at " + pmml.getLocator() + ")");
	}
}