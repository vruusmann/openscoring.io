package jaxb_demo;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.transform.stream.StreamResult;

import org.dmg.pmml.DataDictionary;
import org.dmg.pmml.Header;
import org.dmg.pmml.ObjectFactory;
import org.dmg.pmml.PMML;

public class MarshalDemo {

	static
	public void main(String... args) throws Exception {
		JAXBContext context = JAXBContext.newInstance(ObjectFactory.class);

		Marshaller marshaller = context.createMarshaller();

		PMML pmml = new PMML()
			.setHeader(new Header())
			.setDataDictionary(new DataDictionary());

		marshaller.marshal(pmml, new StreamResult(System.out));
	}
}