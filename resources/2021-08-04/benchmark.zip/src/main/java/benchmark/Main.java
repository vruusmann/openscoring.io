package benchmark;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import net.razorvine.pickle.Pickler;
import net.razorvine.pickle.Unpickler;
import org.dmg.pmml.FieldName;
import org.jpmml.evaluator.Evaluator;
import org.jpmml.evaluator.EvaluatorBuilder;
import org.jpmml.evaluator.LoadingModelEvaluatorBuilder;
import org.jpmml.evaluator.python.PythonUtil;

public class Main {

	static
	public void main(String... args) throws Exception {
		Evaluator evaluator = loadEvaluator(new File(args[0]));

		List<Map<String, ?>> data = loadData(new File(args[1]));

		String flag = args[2];
		String warmUpBatchSize = (args.length > 3 ? args[3] : null);

		System.out.println("| Configuration | Time (sec) | Time per row (microsec) |");

		if(warmUpBatchSize != null){
			evaluate(evaluator, data, Integer.parseInt(warmUpBatchSize));

			if("Python".equals(flag)){
				serialize(data, Integer.parseInt(warmUpBatchSize));
			}
		} // End if

		if("Java".equals(flag)){
			evaluate(evaluator, data, 100000);
		} else

		if("Python".equals(flag)){
			evaluateBatch(evaluator, data);
		} else

		{
			throw new IllegalArgumentException(flag);
		}
	}

	static
	private void evaluate(Evaluator evaluator, List<Map<String, ?>> data, int limit){
		List<Map<String, ?>> sample = makeSample(data, limit);

		long startTime = System.currentTimeMillis();

		for(Map<String, ?> row : sample){
			// XXX
			//Map<FieldName, ?> arguments = row.entrySet().stream()
			//	.collect(Collectors.toMap(entry -> FieldName.create(entry.getKey()), entry -> entry.getValue()));

			Map<FieldName, ?> arguments = new AbstractMap<FieldName, Object>(){

				@Override
				public Set entrySet(){
					throw new UnsupportedOperationException();
				}

				@Override
				public Object get(Object key){
					FieldName name = (FieldName)key;

					return row.get(name.getValue());
				}
			};

			evaluator.evaluate(arguments);
		}

		long endTime = System.currentTimeMillis();

		printSummary("1 * " + sample.size(), (endTime - startTime), sample.size());
	}

	static
	private void evaluateBatch(Evaluator evaluator, List<Map<String, ?>> data) throws IOException {

		for(String config : Arrays.asList("1000 * 1", "1000 * 10", "1000 * 100", "10 * 1000", "10 * 10000", "1 * 100000")){
			List<Integer> nums = Arrays.stream(config.split("\\*"))
				.map(token -> new Integer(token.trim()))
				.collect(Collectors.toList());

			int cycles = nums.get(0);
			int batchSize = nums.get(1);

			List<Map<String, ?>> sample = makeSample(data, batchSize);

			Pickler pickler = new Pickler();

			byte[] sampleBytes = pickler.dumps(sample);

			long startTime = System.currentTimeMillis();

			int numScored = 0;

			for(int i = 0; i < cycles; i++){
				PythonUtil.evaluateAll(evaluator, sampleBytes);

				numScored += sample.size();
			}

			long endTime = System.currentTimeMillis();

			printSummary(config, (endTime - startTime), numScored);
		}
	}

	static
	private void serialize(List<Map<String, ?>> data, int limit) throws IOException {
		List<Map<String, ?>> sample = makeSample(data, 10);

		for(int i = 0; i < limit; i++){
			Pickler pickler = new Pickler();
			Unpickler unpickler = new Unpickler();

			byte[] dump = pickler.dumps(sample);
			unpickler.loads(dump);
		}
	}

	static
	private void printSummary(String config, long elapsedTime, int numScored){
		System.out.println(String.format(Locale.US, "| %1s | %2$.6f | %3$.3f |", config, elapsedTime / 1000.0, (elapsedTime * 1000.0) / numScored));
	}

	static
	private Evaluator loadEvaluator(File pmmlFile) throws Exception {
		EvaluatorBuilder evaluatorBuilder = new LoadingModelEvaluatorBuilder()
			.load(pmmlFile);

		return evaluatorBuilder.build();
	}

	static
	private List<Map<String, ?>> loadData(File csvFile) throws IOException {
		List<Map<String, ?>> table = new ArrayList<>();

		try(BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFile))){
			String headerRow = bufferedReader.readLine();
			List<String> headerCells = Arrays.stream(headerRow.split(","))
				.collect(Collectors.toList());

			while(true){
				String bodyRow = bufferedReader.readLine();
				if(bodyRow == null){
					break;
				}

				List<Object> bodyCells = Arrays.stream(bodyRow.split(","))
					.collect(Collectors.toList());

				if(headerCells.size() != bodyCells.size()){
					throw new IllegalStateException();
				}

				Map<String, Object> row = new HashMap<>();

				cells:
				for(int i = 0; i < headerCells.size(); i++){
					String name = headerCells.get(i);
					Object value = bodyCells.get(i);

					switch(name){
						case "Adjusted":
						case "Deductions":
							continue cells;
						case "Age":
						case "Hours":
							value = Integer.parseInt((String)value);
							break;
						case "Income":
							value = Double.parseDouble((String)value);
							break;
						case "Education":
						case "Employment":
						case "Marital":
						case "Occupation":
						case "Gender":
							value = (String)value;
							break;
						default:
							throw new IllegalStateException();
					}

					row.put(name, value);
				}

				table.add(row);
			}
		}

		return table;
	}

	static
	private <E> List<E> makeSample(List<E> list, int size){
		List<E> result = new ArrayList<>(size);

		Random random = new Random();

		for(int i = 0; i < size; i++){
			result.add(list.get(random.nextInt(list.size())));
		}

		return result;
	}
}