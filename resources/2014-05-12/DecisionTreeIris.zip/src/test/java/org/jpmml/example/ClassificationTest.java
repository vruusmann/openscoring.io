package org.jpmml.example;

import java.util.List;

import com.google.common.collect.MapDifference;

import org.dmg.pmml.FieldName;

import org.jpmml.evaluator.ArchiveBatch;
import org.jpmml.evaluator.Batch;
import org.jpmml.evaluator.BatchUtil;

import org.junit.Assert;
import org.junit.Test;

public class ClassificationTest {

	@Test
	public void evaluateDecisionTreeIris() throws Exception {
		Batch batch = new ArchiveBatch("DecisionTree", "Iris"){};

		List<MapDifference<FieldName, ?>> difference = BatchUtil.difference(batch, 1.e-6, 1.e-6);
		if(!difference.isEmpty()){
			System.err.println(difference);

			Assert.fail();
		}
	}
}